# Nimble Tiny Flat Icons Collection

## Source Introduction
Free Nimble Tiny Flat Icons SVG Vectors and Icons. Nimble Tiny Flat Icons icons and vector packs for Sketch, Adobe XD, Figma and websites. Browse 100 vector icons about Nimble Tiny Flat Icons term.

Source Link: [https://www.svgrepo.com/collection/nimble-tiny-flat-icons](https://www.svgrepo.com/collection/nimble-tiny-flat-icons)

## Modifications
- Adjust the size of all icons to 16x16
- Remove the `<xml>` tags
- Remove comments
- Minified with [`SVGO`](https://svgo.dev/)
